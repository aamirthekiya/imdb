import datetime

from pydantic import BaseModel


class CreateUserSchema(BaseModel):
    name: str
    email_id: str
    mobile_number: str
    age: int or None = None
    password: str
    role: str = "user"


class RequestDetails(BaseModel):
    email_id: str
    password: str


class TokenSchema(BaseModel):
    access_token: str
    refresh_token: str


class CreateToken(BaseModel):
    user_id: str
    access_token: str
    refresh_token: str
    status: bool
    created_date: datetime.datetime
