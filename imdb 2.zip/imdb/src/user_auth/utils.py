import jwt
import logging

from datetime import datetime, timedelta
from fastapi import Request, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from functools import wraps
from jwt.exceptions import InvalidTokenError
from passlib.context import CryptContext
from typing import Union, Any


# Local imports
from src.user_auth.model import Token
from src.user_auth.constant import (
    ACCESS_TOKEN_EXPIRE_MINUTES, REFRESH_TOKEN_EXPIRE_MINUTES, ALGORITHM,
    JWT_SECRET_KEY, JWT_REFRESH_SECRET_KEY
)

password_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def get_hashed_password(password: str) -> str:
    return password_context.hash(password)


def verify_password(password: str, hashed_pass: str) -> bool:
    return password_context.verify(password, hashed_pass)


def create_access_token(subject: Union[str, Any], expires_delta: int = None) -> str:
    if expires_delta is not None:
        expires_delta = datetime.utcnow() + expires_delta

    else:
        expires_delta = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)

    to_encode = {"exp": expires_delta, "sub": str(subject)}
    encoded_jwt = jwt.encode(to_encode, JWT_SECRET_KEY, ALGORITHM)

    return encoded_jwt


def create_refresh_token(subject: Union[str, Any], expires_delta: int = None) -> str:
    if expires_delta is not None:
        expires_delta = datetime.utcnow() + expires_delta
    else:
        expires_delta = datetime.utcnow() + timedelta(minutes=REFRESH_TOKEN_EXPIRE_MINUTES)

    to_encode = {"exp": expires_delta, "sub": str(subject)}
    encoded_jwt = jwt.encode(to_encode, JWT_REFRESH_SECRET_KEY, ALGORITHM)
    return encoded_jwt


def decodeJWT(jwtoken: str):
    try:

        payload = jwt.decode(jwtoken, JWT_SECRET_KEY, ALGORITHM)
        return payload
    except InvalidTokenError:
        return None


class JWTBearer(HTTPBearer):
    def __init__(self, auto_error: bool = True):
        super(JWTBearer, self).__init__(auto_error=auto_error)

    async def __call__(self, request: Request):
        credentials: HTTPAuthorizationCredentials = await super(JWTBearer, self).__call__(request)
        if credentials:
            if not credentials.scheme == "Bearer":
                raise HTTPException(status_code=403, detail="Invalid authentication scheme.")
            if not self.verify_jwt(credentials.credentials):
                raise HTTPException(status_code=403, detail="Invalid token or expired token.")
            return credentials.credentials
        else:
            raise HTTPException(status_code=403, detail="Invalid authorization code.")

    @staticmethod
    def verify_jwt(jwtoken: str) -> bool:
        is_token_valid: bool = False

        try:
            payload = decodeJWT(jwtoken)
        except Exception:
            payload = None

        if payload:
            logging.info(f"Payload: {payload}")
            print(f"payload: {payload}")
            is_token_valid = True

        return is_token_valid


def authorization_check(func):
    @wraps(func)
    def wrapper(*args, **kwargs):

        session = kwargs['session']
        access_token = kwargs['dependencies']
        requested_role = kwargs['requested_role']

        result = Token.get_token_with_user(
            session=session, access_token=access_token
        )
        if not result:
            return {'msg': "Token blocked"}

        try:
            token_data, user = result[0]
        except IndexError:
            logging.info("IndexError while reading the result")
            return HTTPException(status_code=500, detail="something went wrong")

        if token_data:
            logging.info(f"user.role: {user.role}, requested_role: {requested_role}")
            print(f"user.role: {user.role}, requested_role: {requested_role}")
            if user.role == requested_role or user.role == "admin":
                return func(**kwargs)
            return HTTPException(status_code=401, detail="Unauthorized token")

        else:
            return {'msg': "Token blocked"}

    return wrapper
