import datetime

from sqlalchemy import (
    Column, Integer, String, Boolean, DateTime, ForeignKey, func, or_
)

from src.sql.utils import Base, Session


class User(Base):
    __tablename__ = 'imdb_user'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    email_id = Column(String, nullable=False, unique=True)
    mobile_number = Column(String, nullable=False, unique=True)
    age = Column(Integer, nullable=True)
    password = Column(String(100), nullable=False)
    role = Column(String, nullable=False, default="user")
    dt_created = Column(DateTime, default=datetime.datetime.now)
    dt_updated = Column(DateTime, onupdate=func.now(), default=func.now())

    @classmethod
    def get_user_by_id(cls, session: Session, user_id: int):
        return session.query(cls). \
            filter(
            cls.id == int(user_id)
        ).first()

    @classmethod
    def get_user_by_email(cls, session, email_id):
        return session.query(cls).filter(cls.email_id == email_id).first()

    @classmethod
    def get_user_by_email_and_mobile(cls, session, email_id, mobile_number):
        return session.query(cls). \
            filter(or_(
            cls.email_id == email_id,
            cls.mobile_number == mobile_number)
        ).first()

    def to_dict(self):
        return {
            "user_id": self.id,
            "name": self.name,
            "email_id": self.email_id,
            "mobile_number": self.mobile_number,
            "age": self.age,
            "role": self.role
        }


class Token(Base):
    __tablename__ = "token"
    user_id = Column(Integer, ForeignKey("imdb_user.id"))
    access_token = Column(String(450), primary_key=True)
    refresh_token = Column(String(450), nullable=False)
    status = Column(Boolean)
    dt_created = Column(DateTime, default=datetime.datetime.now)
    dt_updated = Column(DateTime, onupdate=func.now(), default=func.now())

    @classmethod
    def get_token_with_user(cls, session: Session, user_id: int = None, access_token: str = None):
        query = session.query(cls, User).join(User, cls.user_id == User.id)

        if user_id:
            query = query.filter(User.id == user_id)

        if access_token:
            query = query.filter(cls.access_token == access_token)

        return query.all()
