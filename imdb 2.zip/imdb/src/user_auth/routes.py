# Lib imports
import logging

from fastapi import Depends, HTTPException, status, APIRouter
from sqlalchemy.exc import SQLAlchemyError

# Local imports
from src.sql.utils import Session, get_session
from src.user_auth.model import User, Token
from src.user_auth.schema import CreateUserSchema, RequestDetails
from src.user_auth.utils import get_hashed_password, verify_password, create_access_token, create_refresh_token


user_auth_router = APIRouter()


@user_auth_router.post("/register")
async def create_user(user: CreateUserSchema, session: Session = Depends(get_session)):
    existing_user = User.get_user_by_email_and_mobile(
        session=session,
        email_id=user.email_id,
        mobile_number=user.mobile_number
    )
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")

    encrypted_password = get_hashed_password(user.password)

    new_user = User()
    new_user.name = user.name
    new_user.email_id = user.email_id
    new_user.mobile_number = user.mobile_number
    new_user.age = user.age
    new_user.password = encrypted_password
    new_user.role = user.role if user.role else "user"

    session.add(new_user)
    try:
        session.commit()
    except SQLAlchemyError as e:
        logging.info(f"Error while creating user: {e}")
        session.rollback()
        raise HTTPException(status_code=500, detail="something went wrong")

    return {"message": "user created successfully"}


@user_auth_router.post("/login")
async def login_user(request: RequestDetails, session: Session = Depends(get_session)):
    user = User.get_user_by_email(session=session, email_id=request.email_id)
    if user is None:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Incorrect email")

    hashed_pass = user.password
    if not verify_password(request.password, hashed_pass):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Incorrect password"
        )

    access = create_access_token(str(user.id))
    refresh = create_refresh_token(str(user.id))

    new_token = Token()
    new_token.user_id = user.id
    new_token.access_token = access
    new_token.refresh_token = refresh
    new_token.status = True

    session.add(new_token)
    try:
        session.commit()
    except SQLAlchemyError as e:
        logging.info(f"Error while creating token: {e}")
        session.rollback()
        raise HTTPException(status_code=500, detail="something went wrong")

    return {
        "access_token": access,
        "refresh_token": refresh,
    }
