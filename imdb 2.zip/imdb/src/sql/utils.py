from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

from src.sql.constant import SQL_INSTANCE_URI


engine = create_engine(SQL_INSTANCE_URI, connect_args={'connect_timeout': 10})
Base = declarative_base()

Session = sessionmaker(bind=engine)


def get_session():
    session = Session()
    try:
        yield session
    finally:
        session.close()
