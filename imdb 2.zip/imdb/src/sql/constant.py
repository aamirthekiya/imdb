import os


POSTGRES_USER = os.getenv("POSTGRES_USER") or "postgres"
POSTGRES_PASSWORD = os.getenv("POSTGRES_PASSWORD") or "postgres123"
DB_URL = os.getenv("DB_URL") or "localhost:5432"
DB_NAME = os.getenv("POSTGRES_DB") or "imdb"

SQL_INSTANCE_URI = f'postgresql+psycopg2://{POSTGRES_USER}:{POSTGRES_PASSWORD}@{DB_URL}/{DB_NAME}'
