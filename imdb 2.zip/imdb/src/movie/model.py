import datetime

from sqlalchemy import (
    ARRAY, Column, DateTime, Float, func, Integer, String
)

from src.sql.utils import Base, Session


class Movie(Base):
    __tablename__ = 'movie'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False, index=True)
    director = Column(String, nullable=False)
    genre = Column(ARRAY(String))
    imdb_score = Column(Float)
    popularity = Column(Float)
    dt_created = Column(DateTime, default=datetime.datetime.now)
    dt_updated = Column(DateTime, onupdate=func.now(), default=func.now())

    @classmethod
    def get_by(cls, session: Session, movie_id: int = None, movie_name: str = None, director: str = None,
               min_score: float = None, max_score: float = None, min_popularity: float = None,
               max_popularity: float = None, genre: str = None, pagination: bool = False, page_no: int = 1,
               page_size: int = 10):
        query = session.query(cls)

        if movie_id:
            query = query.filter(cls.id == movie_id)

        if movie_name:
            query = query.filter(cls.name == movie_name)

        if director:
            query = query.filter(cls.director == director)

        if genre:
            query = query.filter(cls.genre.contains([genre]))

        if min_score:
            query = query.filter(cls.imdb_score >= min_score)

        if max_score:
            query = query.filter(cls.imdb_score <= max_score)

        if min_popularity:
            query = query.filter(cls.popularity >= min_popularity)

        if max_popularity:
            query = query.filter(cls.popularity <= max_popularity)

        if pagination:
            query = query.limit(page_size).offset((page_no - 1) * page_size)

        return query.all()

    def to_dict(self):
        return {
            "movie_id": self.id,
            "name": self.name,
            "director": self.director,
            "genre": self.genre,
            "imdb_score": self.imdb_score,
            "popularity": self.popularity
        }
