# Lib imports
import logging

from fastapi import Depends, HTTPException, APIRouter
from sqlalchemy.exc import SQLAlchemyError

# Local imports
from src.sql.utils import Session, get_session
from src.movie.schema import CreateMovieSchema, UpdateMovieSchema
from src.movie.model import Movie
from src.movie.helper import validate_movie
from src.user_auth.utils import authorization_check, JWTBearer


movie_router = APIRouter()


@movie_router.get("/get/{movie_id}")
@authorization_check
def get_movie_by_id(
        movie_id: int,
        dependencies=Depends(JWTBearer()),
        session: Session = Depends(get_session),
        requested_role: str = "user",
):

    movies = Movie.get_by(session=session, movie_id=movie_id)
    if not movies:
        raise HTTPException(status_code=404, detail="Movie not found")

    try:
        movie = movies[0]
    except IndexError:
        raise HTTPException(status_code=500, detail="Something went wrong")

    return {
        "message": "movie fetch successfully",
        "movie": movie.to_dict()
    }


@movie_router.get("/")
@authorization_check
def get_all_movies(
        movie_name: str = None, director: str = None,
        genre: str = None, min_score: float = None,
        max_score: float = None, min_popularity: float = None,
        max_popularity: float = None, page_no: int = 1, page_size: int = 10,
        pagination:bool = False, dependencies=Depends(JWTBearer()),
        session: Session = Depends(get_session),
        requested_role: str = "user",
):

    movies = Movie.get_by(
        session=session,
        movie_name=movie_name,
        director=director,
        genre=genre,
        min_score=min_score,
        max_score=max_score,
        min_popularity=min_popularity,
        max_popularity=max_popularity,
        pagination=pagination,
        page_no=page_no,
        page_size=page_size
    )

    return {
        "message": "movie fetch successfully",
        "movies": [movie.to_dict() for movie in movies]
    }


@movie_router.post("/create")
@authorization_check
def create_movie(
        movie: CreateMovieSchema,
        session: Session = Depends(get_session),
        requested_role: str = "admin",
        dependencies=Depends(JWTBearer())
):

    movies = Movie.get_by(session=session, movie_name=movie.name)
    if movies:
        raise HTTPException(status_code=400, detail="Movie is already present")

    new_movie = Movie()
    new_movie.name = movie.name
    new_movie.director = movie.director
    new_movie.genre = movie.genre
    new_movie.imdb_score = round(movie.imdb_score, 2)
    new_movie.popularity = round(movie.popularity, 2)

    validate_movie(new_movie)

    session.add(new_movie)
    try:
        session.commit()
    except SQLAlchemyError as e:
        logging.info(f"Error while creating movie: {e}")
        session.rollback()
        raise HTTPException(status_code=500, detail="something went wrong")

    return {
        "message": "movie created",
        "movie": new_movie.to_dict()
    }


@movie_router.put("/update/{movie_id}")
@authorization_check
def update_movie(
        movie_id: int,
        movie_data_to_update: UpdateMovieSchema,
        dependencies=Depends(JWTBearer()),
        session: Session = Depends(get_session),
        requested_role: str = "admin",
):

    movies = Movie.get_by(session=session, movie_id=movie_id)
    if not movies:
        raise HTTPException(status_code=404, detail="Movie not found")

    try:
        movie = movies[0]
    except IndexError:
        raise HTTPException(status_code=500, detail="Something went wrong")

    if movie_data_to_update.name and movie_data_to_update.name != movie.name:
        movies = Movie.get_by(session=session, movie_name=movie_data_to_update.name)
        if movies:
            raise HTTPException(status_code=400, detail="Movie name already exist")

        movie.name = movie_data_to_update.name

    if movie_data_to_update.director:
        movie.director = movie_data_to_update.director

    if movie_data_to_update.imdb_score:
        movie.imdb_score = movie_data_to_update.imdb_score

    if movie_data_to_update.popularity:
        movie.popularity = movie_data_to_update.popularity

    if movie_data_to_update.genre:
        movie.genre = movie_data_to_update.genre

    validate_movie(movie=movie)

    session.add(movie)

    try:
        session.commit()
    except SQLAlchemyError as e:
        logging.info(f"Error while updating movie: {e}")
        session.rollback()
        raise HTTPException(status_code=500, detail="something went wrong")

    return {
        "message": "movie updated",
        "movie": movie.to_dict()
    }


@movie_router.delete("/delete/{movie_id}")
@authorization_check
def delete_movie(movie_id: int, requested_role: str = "admin",
                 dependencies=Depends(JWTBearer()),
                 session: Session = Depends(get_session)
):
    movies = Movie.get_by(session=session, movie_id=movie_id)
    if movies is None or len(movies) < 1:
        raise HTTPException(status_code=404, detail="Movie not found")

    try:
        movie = movies[0]
    except IndexError:
        raise HTTPException(status_code=500, detail="Something went wrong")

    session.delete(movie)
    try:
        session.commit()
    except SQLAlchemyError as e:
        logging.info(f"Error while deleting the movie: {e}")
        session.rollback()
        raise HTTPException(status_code=500, detail="something went wrong")
    return {"message": f"Movie deleted successfully"}
