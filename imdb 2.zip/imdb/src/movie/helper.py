
from fastapi import HTTPException

from src.movie.model import Movie


def validate_movie(movie: Movie):

    if movie.imdb_score < 0 or movie.imdb_score > 10.00:
        raise HTTPException(status_code=400, detail="IMDB score should between 0 - 10")

    if movie.popularity < 0 or movie.popularity > 100.00:
        raise HTTPException(status_code=400, detail="popularity should between 0 - 100")

    if len(movie.genre) < 1:
        raise HTTPException(status_code=400, detail="minimum 1 genre is required")
