
from pydantic import BaseModel


class CreateMovieSchema(BaseModel):
    name: str
    director: str
    genre: list[str]
    imdb_score: float
    popularity: float


class UpdateMovieSchema(BaseModel):
    name: str = ''
    director: str = ''
    genre: list[str] = []
    imdb_score: float or None = None
    popularity: float or None = None
