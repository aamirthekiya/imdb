import json
import os

from fastapi import FastAPI, Depends, HTTPException

from src.sql.utils import Base, engine, Session, get_session
from src.user_auth.routes import user_auth_router
from src.movie.routes import movie_router
from src.movie.model import Movie

Base.metadata.create_all(engine)

app = FastAPI()
app.include_router(user_auth_router, prefix="/api/user")
app.include_router(movie_router, prefix="/api/movie")


@app.get("/")
async def hello_world():
    return {"message": "server is running"}


@app.post("/api/load_data")
async def load_data(session: Session = Depends(get_session)):
    file_name = os.getenv("DATA_FILE_NAME")
    try:
        with open(file_name, "r") as json_file:
            data = json.load(json_file)

            for movie_data in data:
                movie = Movie()
                movie.name = movie_data.get("name")
                movie.director = movie_data.get("director")
                movie.genre = movie_data.get("genre")
                movie.imdb_score = movie_data.get("imdb_score")
                movie.popularity = movie_data.get("99popularity")

                session.add(movie)

            session.commit()
            return {"message": "Data loaded successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to load data: {str(e)}")
